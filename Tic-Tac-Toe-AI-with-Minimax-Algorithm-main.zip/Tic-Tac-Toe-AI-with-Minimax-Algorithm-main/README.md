# Tic Tac Toe AI with Minimax Algorithm

Watch the Youtube Video from [here](https://youtu.be/YWolTTaFauk)

# Project setup

### Clone the project
```shell
git clone https://github.com/Code-Challenge-YT/Tic-Tac-Toe-AI-with-Minimax-Algorithm.git
```

### Compile the code
```shell
g++ main.cpp -o main.exe
```

### Run compiled output
```shell
./main.cpp
```